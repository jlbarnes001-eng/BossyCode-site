# BossyCode — Next.js at Repo Root

This repo is **already flattened** so Vercel detects **Framework: Next.js** automatically.

## Local
```bash
npm install
npm run dev
# http://localhost:3000
```

## Deploy (Vercel)
- Push this **root** to GitHub (no nested folder).
- Import repo in Vercel → it should show **Next.js** (not “Other”).
- No Root Directory override needed.

© 2025 BossyCode
