export default function Page() {
  return (
    <main className="min-h-screen bg-white text-zinc-900 flex items-center justify-center p-6">
      <div className="text-center max-w-2xl">
        <h1 className="text-4xl font-bold">Copilot writes. <span className="text-blue-600">BossyCode ships.</span></h1>
        <p className="mt-4 text-lg text-zinc-600">Clean Next.js app (App Router) at repo root. Ready for Vercel — no nested folders.</p>
      </div>
    </main>
  );
}
