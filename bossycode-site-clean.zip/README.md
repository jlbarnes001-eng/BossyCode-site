# BossyCode Clean Landing

This is a minimal Next.js + Tailwind site (no file-backed API).

## Local Dev
```bash
npm install
npm run dev
```

## Deploy (Vercel)
Push to GitHub → Import on Vercel → done.

© 2025 BossyCode
