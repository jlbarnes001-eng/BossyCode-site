import './globals.css';
export const metadata = {
  title: 'BossyCode',
  description: 'Copilot writes. BossyCode ships.',
};
export default function RootLayout({ children }) {
  return <html lang="en"><body>{children}</body></html>;
}
