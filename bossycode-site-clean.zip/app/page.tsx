export default function Page() {
  return (
    <main className="min-h-screen bg-white text-zinc-900 flex items-center justify-center">
      <div className="text-center">
        <h1 className="text-4xl font-bold">Copilot writes. <span className="text-blue-600">BossyCode ships.</span></h1>
        <p className="mt-4 text-lg text-zinc-600">Landing page is live. Waitlist form to be integrated soon.</p>
      </div>
    </main>
  );
}
