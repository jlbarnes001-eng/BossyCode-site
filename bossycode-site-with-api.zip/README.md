# BossyCode Landing (Next.js + Tailwind)

**Copilot writes. BossyCode ships.**  
This is a lean landing page with a waitlist form placeholder.

## Local Dev
```bash
pnpm install # or npm/yarn
pnpm dev
# open http://localhost:3000
```

## Deploy (Vercel)
- Create a new project on Vercel and import this repo.
- Optional: set `NEXT_PUBLIC_WAITLIST_ACTION` env var to your form endpoint.

© 2025 BossyCode


## Waitlist Storage (No Mailchimp)
This template includes an **/api/waitlist** route that writes signups to `data/waitlist.json` and `data/waitlist.csv`.
- ✅ Works locally and on hosts with writable disk (VPS, Docker, Render with persistent disk).
- ⚠️ **Vercel note:** the filesystem is ephemeral at runtime, so this file-based storage **won’t persist** across deployments.
  - Quick alternatives without a business address:
    - **Supabase (free):** Postgres table for signups.
    - **Airtable:** simple base with a webhook connector.
    - **Google Sheets (Apps Script Web App):** acts as a simple backend.
  - I can help wire any of these in `/app/api/waitlist/route.ts`.

