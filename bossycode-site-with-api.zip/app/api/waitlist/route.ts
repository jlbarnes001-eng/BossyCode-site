import { NextResponse } from 'next/server';
import { promises as fs } from 'fs';
import path from 'path';

type Payload = { name: string; email: string; github?: string | null };

function isValidEmail(email: string) {
  return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email);
}

export async function POST(req: Request) {
  try {
    const body = await req.formData();
    const name = String(body.get('name') || '').trim();
    const email = String(body.get('email') || '').trim();
    const github = String(body.get('github') || '').trim() || null;

    if (!name || !email || !isValidEmail(email)) {
      return NextResponse.json({ ok: false, error: 'invalid_input' }, { status: 400 });
    }

    const record: Payload & { ts: string } = {
      name, email, github, ts: new Date().toISOString(),
    };

    const dataDir = path.join(process.cwd(), 'data');
    const jsonPath = path.join(dataDir, 'waitlist.json');
    const csvPath = path.join(dataDir, 'waitlist.csv');

    await fs.mkdir(dataDir, { recursive: true });

    // Append JSON array
    let arr: any[] = [];
    try {
      const existing = await fs.readFile(jsonPath, 'utf8');
      arr = JSON.parse(existing);
      if (!Array.isArray(arr)) arr = [];
    } catch {}
    arr.push(record);
    await fs.writeFile(jsonPath, JSON.stringify(arr, null, 2), 'utf8');

    // Append CSV line
    const header = 'timestamp,name,email,github\n';
    const line = `${record.ts},"${record.name.replaceAll('"','""')}",${record.email},${record.github ?? ''}\n`;
    try {
      await fs.access(csvPath);
    } catch {
      await fs.writeFile(csvPath, header, 'utf8');
    }
    await fs.appendFile(csvPath, line, 'utf8');

    return NextResponse.redirect('/thank-you', { status: 303 });
  } catch (e) {
    console.error(e);
    return NextResponse.json({ ok: false, error: 'server_error' }, { status: 500 });
  }
}
