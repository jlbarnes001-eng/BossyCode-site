import './globals.css';
import type { Metadata } from 'next';

export const metadata: Metadata = {
  title: 'BossyCode — Copilot writes. BossyCode ships.',
  description: 'The AI finisher that takes code from draft → PR with logs, PLAN.md, tests and safe preview deploys.',
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en">
      <body>{children}</body>
    </html>
  );
}
