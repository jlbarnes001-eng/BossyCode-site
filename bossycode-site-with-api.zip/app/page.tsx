export default function Page() {
  return (
    <main className="min-h-screen bg-white text-zinc-900">
      {/* Header */}
      <header className="mx-auto flex max-w-6xl items-center justify-between px-6 py-5">
        <div className="flex items-center gap-3">
          <div className="grid h-9 w-9 place-items-center rounded-xl bg-zinc-900 text-white">{`{}`}</div>
          <span className="text-xl font-semibold">BossyCode</span>
        </div>
        <nav className="hidden items-center gap-6 text-sm md:flex">
          <a href="#how" className="hover:underline">How it works</a>
          <a href="#demo" className="hover:underline">Demo</a>
          <a href="#security" className="hover:underline">Security</a>
          <a href="#waitlist" className="rounded-full border px-4 py-1.5 hover:bg-zinc-50">Join waitlist</a>
        </nav>
      </header>

      {/* Hero */}
      <section className="relative mx-auto max-w-6xl px-6 pb-8 pt-10">
        <div className="grid items-center gap-8 md:grid-cols-2">
          <div>
            <h1 className="text-4xl font-bold tracking-tight md:text-5xl">
              Copilot writes. <span className="text-blue-600">BossyCode ships.</span>
            </h1>
            <p className="mt-3 max-w-xl text-lg text-zinc-600">
              The AI finisher that takes code from draft → PR with logs, PLAN.md, tests and safe preview deploys.
            </p>
            <div className="mt-6 flex flex-wrap gap-3">
              <a
                href="#waitlist"
                className="rounded-xl bg-blue-600 px-5 py-3 text-white shadow-sm transition hover:bg-blue-700"
              >
                Join the Waitlist
              </a>
              <a
                href="#demo"
                className="rounded-xl border border-zinc-300 px-5 py-3 text-zinc-800 hover:bg-zinc-50"
              >
                Watch 90s Demo
              </a>
            </div>
            <div className="mt-6 text-sm text-zinc-500">
              <span className="mr-2 inline-block rounded-full bg-green-100 px-2 py-0.5 text-green-700">~75% faster</span>
              45 minutes saved per feature (measured on our Express Auth demo)
            </div>
          </div>

          {/* Video placeholder */}
          <div id="demo" className="relative aspect-video w-full overflow-hidden rounded-2xl border bg-zinc-50">
            <div className="absolute inset-0 grid place-items-center">
              <div className="text-center">
                <div className="mb-2 text-sm uppercase tracking-wider text-zinc-500">Demo Placeholder</div>
                <div className="text-3xl font-bold">90‑second tangible demo</div>
                <p className="mt-2 text-zinc-600">Embed your MP4 / YouTube here</p>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* How it works */}
      <section id="how" className="mx-auto max-w-6xl px-6 py-12">
        <h2 className="text-2xl font-semibold">How it works</h2>
        <div className="mt-6 grid gap-4 md:grid-cols-3">
          <Card step="01" title="Install GitHub App" desc="Connect your repo so BossyCode can open PRs with artifacts." />
          <Card step="02" title="Add bossycode.yml" desc="Define intents like quick_smoke or feature_auth and acceptance tests." />
          <Card step="03" title="Comment to run" desc="Type /bossycode run feature_auth → PR with PLAN.md, logs, preview." />
        </div>
      </section>

      {/* Value props */}
      <section className="mx-auto max-w-6xl px-6 py-12">
        <div className="grid gap-4 md:grid-cols-4">
          <Value title="Explainable" desc="Every run emits logs + PLAN.md. No black boxes." />
          <Value title="Safe by default" desc="Docker sandbox, non‑root, rollback‑ready previews." />
          <Value title="Seamless" desc="Lives in your GitHub PRs. Zero new portals." />
          <Value title="Time‑saving" desc="Proven minutes back per feature. Ship more." />
        </div>
      </section>

      {/* Security */}
      <section id="security" className="mx-auto max-w-6xl px-6 py-12">
        <div className="rounded-2xl border p-6">
          <h3 className="text-xl font-semibold">Security baseline</h3>
          <ul className="mt-3 list-disc space-y-1 pl-5 text-zinc-700">
            <li>Zero‑trust defaults</li>
            <li>Ephemeral sandboxes, non‑root, restricted egress</li>
            <li>Secrets isolation (Vault/Doppler ready)</li>
            <li>Audit trails in <code className="rounded bg-zinc-100 px-1">.artifacts/bossycode/</code></li>
          </ul>
          <a href="/security" className="mt-4 inline-block text-blue-600 hover:underline">Read full baseline →</a>
        </div>
      </section>

      {/* Waitlist */}
      <section id="waitlist" className="mx-auto max-w-6xl px-6 py-12">
        <div className="grid gap-8 rounded-2xl border p-6 md:grid-cols-2">
          <div>
            <h3 className="text-2xl font-semibold">Get early access</h3>
            <p className="mt-2 text-zinc-600">Join the beta waitlist. We’ll notify you as invites roll out.</p>
            <p className="mt-4 text-sm text-zinc-500">We respect your inbox. No spam.</p>
          </div>
          <form
            className="grid gap-3"
            method="post"
            action="/api/waitlist"
          >
            <label className="grid gap-1">
              <span className="text-sm text-zinc-700">Name</span>
              <input name="name" required placeholder="Ada Lovelace" className="rounded-xl border px-3 py-2 outline-none ring-blue-500 focus:ring-2" />
            </label>
            <label className="grid gap-1">
              <span className="text-sm text-zinc-700">Email</span>
              <input type="email" name="email" required placeholder="you@company.com" className="rounded-xl border px-3 py-2 outline-none ring-blue-500 focus:ring-2" />
            </label>
            <label className="grid gap-1">
              <span className="text-sm text-zinc-700">GitHub (optional)</span>
              <input name="github" placeholder="https://github.com/your-handle" className="rounded-xl border px-3 py-2 outline-none ring-blue-500 focus:ring-2" />
            </label>
            <button type="submit" className="mt-2 rounded-xl bg-blue-600 px-5 py-3 font-medium text-white transition hover:bg-blue-700">Join waitlist</button>
            <p className="text-xs text-zinc-500">By joining, you agree to our <a href="/privacy" className="underline">Privacy Policy</a>.</p>
          </form>
        </div>
      </section>

      {/* Footer */}
      <footer className="mx-auto max-w-6xl px-6 pb-10 pt-6 text-sm text-zinc-500">
        <div className="flex flex-col items-start justify-between gap-3 md:flex-row md:items-center">
          <p>© {new Date().getFullYear()} BossyCode. Security: <a href="mailto:security@bossycode.com" className="underline">security@bossycode.com</a></p>
          <div className="flex gap-4">
            <a href="/docs" className="hover:underline">Docs</a>
            <a href="/security" className="hover:underline">Security</a>
            <a href="/pricing" className="hover:underline">Pricing</a>
            <a href="https://twitter.com/" target="_blank" rel="noreferrer" className="hover:underline">Twitter</a>
          </div>
        </div>
      </footer>
    </main>
  );
}

function Card({ step, title, desc }: { step: string; title: string; desc: string }) {
  return (
    <div className="rounded-2xl border p-5">
      <div className="text-xs font-semibold uppercase tracking-wider text-zinc-500">Step {step}</div>
      <div className="mt-1 text-lg font-semibold">{title}</div>
      <p className="mt-1 text-zinc-600">{desc}</p>
    </div>
  );
}

function Value({ title, desc }: { title: string; desc: string }) {
  return (
    <div className="rounded-2xl border p-5">
      <div className="text-lg font-semibold">{title}</div>
      <p className="mt-1 text-zinc-600">{desc}</p>
    </div>
  );
}
