export default function Privacy() {
  return (
    <main className="mx-auto max-w-3xl px-6 py-12 text-zinc-800">
      <h1 className="text-3xl font-bold">Privacy Policy</h1>
      <p className="mt-4 text-zinc-600">We respect your privacy. This is a placeholder policy for the MVP.</p>
    </main>
  );
}
