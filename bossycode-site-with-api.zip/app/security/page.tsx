export default function Security() {
  return (
    <main className="mx-auto max-w-3xl px-6 py-12 text-zinc-800">
      <h1 className="text-3xl font-bold">Security</h1>
      <ul className="mt-4 list-disc space-y-2 pl-5 text-zinc-700">
        <li>Zero‑trust defaults</li>
        <li>Ephemeral sandboxes, non‑root, restricted egress</li>
        <li>Secrets isolation (Vault/Doppler ready)</li>
        <li>Audit trails in <code className="rounded bg-zinc-100 px-1">.artifacts/bossycode/</code></li>
      </ul>
    </main>
  );
}
