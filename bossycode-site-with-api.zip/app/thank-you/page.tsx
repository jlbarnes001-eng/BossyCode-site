export default function ThankYou() {
  return (
    <main className="mx-auto grid min-h-[60vh] max-w-2xl place-items-center px-6 py-16 text-center text-zinc-800">
      <div>
        <h1 className="text-3xl font-bold">You're on the waitlist 🎉</h1>
        <p className="mt-3 text-zinc-600">
          Thanks for your interest in BossyCode. We’ll email you as soon as invites roll out.
        </p>
        <a href="/" className="mt-6 inline-block rounded-xl border px-4 py-2 text-zinc-800 hover:bg-zinc-50">Back to home</a>
      </div>
    </main>
  );
}
